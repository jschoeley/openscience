# Project title

Jonas Schöley [![ORCID](https://info.orcid.org/wp-content/uploads/2019/11/orcid_16x16.png)](https://orcid.org/0000-0002-3340-8518) ·

Project description.

# Repository guidelines

Place downloaded or otherwise acquired data in `dat/`. Don't use `dat/` for derived data. Use `out/` for any persistent output of your scripts, e.g. plots, derived data, tables. Use `tmp/` for disposable output. Place scripts in `src/`. Place code which is called across scripts in `src/_global_objects.R`.

This repository uses `renv` for package management. Declare package dependencies explicitly in `_install_dependencies.R`.

`Make` is used as build system.

Constants which are reused across scripts go into `cfg/config.yaml`.
