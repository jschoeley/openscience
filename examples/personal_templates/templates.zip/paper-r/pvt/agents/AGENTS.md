## Coding style

Less is more. Write only the code required to do the task at hand and not more. Special cases should only be handled as they become relevant, and not in anticipation.

Use `R` in this repository.

When writing a script, follow the conventions in this template:

```R
# What does the script do?
#
# How does the script do it?

# Init --------------------------------------------------------------------

library(yaml)

# Constants ---------------------------------------------------------------

# input and output paths
setwd(".")
paths <- list()
paths$input <- list(
  tmp = "./tmp",
  config.yaml = "./cfg/config.yaml",
  global_objects.R = "./src/_global_objects.R"
)
paths$output <- list(
  tmp = paths$input$tmp,
  out.csv = "./dat/out.csv"
)

# global configuration
config <- read_yaml(paths$input$config.yaml)

# global objects and functions
global <- source(paths$input$global)

# constants specific to this analysis
cnst <- within(list(), {})

# Export ------------------------------------------------------------------

# export results of analysis
# What does the script do?
#
# How does the script do it?

# Init --------------------------------------------------------------------

library(yaml)

# Constants ---------------------------------------------------------------

# input and output paths
setwd(".")
paths <- list()
paths$input <- list(
  tmp = "./tmp",
  config.yaml = "./cfg/config.yaml",
  global_objects.R = "./src/_global_objects.R"
)
paths$output <- list(
  tmp = paths$input$tmp,
  out.csv = "./dat/out.csv"
)

# global configuration
config <- read_yaml(paths$input$config.yaml)

# global objects and functions
global <- source(paths$input$global)

# constants specific to this analysis
cnst <- within(list(), {})

# Export ------------------------------------------------------------------

# export results of analysis
```

Use `CamelCase` for functions and `lower_case` for everything else.

## Folder structure

Place downloaded or otherwise acquired data in `dat/`. Don't use `dat/` for derived data. Use `out/` for any persistent output of your scripts, e.g. plots, derived data, tables. Use `tmp/` for disposable output.

Place scripts in `src`. Place code which is relevant for all scripts in `src/_global_objects.R`.

Constants which are reused across scripts go into `cfg/config.yaml`.

## Dependency management

This repository uses renv for package management. Declare package dependencies explicitly in `_install_dependencies.R`.

## Build system

Make is used as build system for the project. Keep the makefile simple.

## Plotting

Use `ggplot2`.

Export Figures using the `ExportSVG()` function.

Use consistent colors across plots and define them in the `cfg/config.yaml`.

Use the `MyGGplotTheme` from the `_global_objects.R`.

When exporting a plot, export the associated data as well.

## Data export

Prefer `.csv` for small tabular data (<100 MB). For larger data and non-tabular data prefer `.qs2` from the `qs2` library. Small statistical tables should be prepared using `gt` library and exported as `.tex` and `html`.

## Log

Write a log of your work in this repository in `pvt/agents/LOG.md`

