---
title: Project diary
id: yyyy-mm-id
description: Human written project diary. No agents allowed here!
people:
	- Jonas Schöley <schoeley@demogr.mpg.de>
---

## yyyy-mm-dd, Entry

