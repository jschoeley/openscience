# What does the script do?
#
# How does the script do it?

# Init --------------------------------------------------------------------

library(yaml)

# Constants ---------------------------------------------------------------

# input and output paths
setwd(".")
paths <- list()
paths$input <- list(
  tmp = "./tmp",
  config.yaml = "./cfg/config.yaml",
  global_objects.R = "./src/_global_objects.R"
)
paths$output <- list(
  tmp = paths$input$tmp,
  out.csv = "./dat/out.csv"
)

# global configuration
config <- read_yaml(paths$input$config.yaml)

# global objects and functions
global <- source(paths$input$global)

# constants specific to this analysis
cnst <- within(list(), {})

# Export ------------------------------------------------------------------

# export results of analysis
