# Install required packages to local renv repository

# define repositories
repositories <- c(
  PPM = "https://packagemanager.posit.co/cran/latest"
)
options(repos = repositories)

# define packages to install from cran-like repositories
cran <- c(
  "yaml",
  "svglite"
)

# define packages to install from github
github <- c(
  #pfs = "jschoeley/pfs@a14c6b2dcd0877cd606ea0aef69c62c013d88fab"
)

all_package_names <-
  c(cran, names(github))

# initialize renv without restarting this R session
if (!file.exists("renv/activate.R")) {
  renv::init(
    bare = TRUE,
    repos = repositories,
    restart = FALSE
  )
}

# install cran packages
renv::install(
  cran,
  dependencies = "strong",
  repos = repositories,
  prompt = FALSE
)

# install GitHub packages
renv::install(
  unname(github),
  dependencies = "strong",
  prompt = FALSE
)

# make a record of installed packages
renv::snapshot(
  packages = all_package_names,
  repos = repositories,
  prompt = FALSE
)
