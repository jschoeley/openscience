---
title: "Title"
date: yyyy-mm-dd
toc: true
numbersections: true
---

# Verdict

**Revise and resubmit**

Summary comments.

# Major comments

## Please do this

Description.

# Minor comments

## Please do this

Description.