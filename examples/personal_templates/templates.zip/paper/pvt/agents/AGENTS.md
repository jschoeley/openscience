## Coding style

Less is more. Write only the code required to do the task at hand and not more. Special cases should only be handled as they become relevant, and not in anticipation.

When writing a script, follow the conventions in this template.

```text
# What does the script do?
#
# How does the script do it?

# Init --------------------------------------------------------------------

# - library import

# Constants ---------------------------------------------------------------

# - input and output path definitions
# - global configuration import
# - global objects and function import
# - definition of constants specific to this analysis

# Functions ---------------------------------------------------------------

# - definition of functions specific to this analysis

# Analysis ----------------------------------------------------------------

# - perform data analysis

# Export ------------------------------------------------------------------

# - export results of analysis
```

Use `CamelCase` for functions and `lower_case` for everything else.

## Folder structure

Place downloaded or otherwise acquired data in `dat/`. Don't use `dat/` for derived data. Use `out/` for any persistent output of your scripts, e.g. plots, derived data, tables. Use `tmp/` for disposable output. Place scripts in `src/`.

Constants which are reused across scripts go into `cfg/config.yaml`.

## Dependency management

Choose a dependency management system which is explicit and allows for version pinning.

## Build system

Make is used as build system for the project. Keep the makefile simple.

## Log

Write a log of your work in this repository in `pvt/agents/LOG.md`
